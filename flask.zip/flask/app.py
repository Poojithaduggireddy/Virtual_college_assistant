from flask import Flask, send_from_directory, render_template, abort, send_file
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/files/<path:filename>')
def serve_files(filename):
    try:
        directory = 'static'  # Directory where your files are stored within the Docker container
        file_path = os.path.join(directory, filename)
        if os.path.exists(file_path):
            return send_from_directory(directory, filename)
        else:
            app.logger.error(f"File not found: {file_path}")
            abort(404)
    except Exception as e:
        app.logger.error(f"Error serving file: {e}")
        abort(500)

@app.route('/academic-calendar')
def serve_academic_calendar():
    try:
        image_path = 'static/academic_calendar.jpg'  # Path to your academic calendar image within the Docker container
        if os.path.exists(image_path):
            return send_file(image_path, mimetype='image/jpeg')
        else:
            app.logger.error(f"Academic calendar image not found: {image_path}")
            abort(404)
    except Exception as e:
        app.logger.error(f"Error serving academic calendar image: {e}")
        abort(500)

@app.route('/images/timetables/<filename>')
def serve_timetable(filename):
    directory = 'static'  # Directory where your timetable images are stored within the Docker container
    try:
        return send_from_directory(directory, filename)
    except Exception as e:
        app.logger.error(f"Error serving timetable image: {e}")
        abort(500)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
