from typing import Any, Text, Dict, List
import mysql.connector
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet
from rasa_sdk.types import DomainDict
from datetime import datetime, timedelta
import os
import urllib.parse
from fuzzywuzzy import process


class ActionSelectOption(Action):
    def name(self) -> Text:
        return "action_select_option"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        dispatcher.utter_message("Hello and welcome to Virtual MVSR! It's wonderful to see you.")
        dispatcher.utter_message("Are you a student, faculty, or visitor?")
        return []


class ActionSetUserType(Action):
    def name(self) -> Text:
        return "action_set_user_type"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        user_type = tracker.latest_message['text'].lower()
        if user_type in ["student", "faculty", "visitor"]:
            return [SlotSet("user_type", user_type)]
        else:
            dispatcher.utter_message("Invalid option. Please select student, faculty, or visitor.")
            return [SlotSet("user_type", None)]
            return []


class ActionAskLogin(Action):
    def name(self) -> Text:
        return "action_ask_login"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        user_type = tracker.get_slot("user_type")
        if user_type == "visitor":
            dispatcher.utter_message("Welcome to MVSR! We're here to assist you with any questions you have—no login required for visitors!")
            return []
        dispatcher.utter_message("Please provide your login credentials")
        return []


class ActionValidateLogin(Action):
    def name(self) -> Text:
        return "action_validate_login"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        # Extract slots
        username = tracker.get_slot("username")
        password = tracker.get_slot("password")
        user_type = tracker.get_slot("user_type")

        if user_type == "visitor":
            dispatcher.utter_message("Welcome to MVSR! We're here to assist you with any questions you have—no login required for visitors!")
            return []

        # Connect to MySQL database
        db_connection = mysql.connector.connect(
            host="dev-mysql",
            user="root",
            password="",
            database="studentdb"
        )
        cursor = db_connection.cursor()

        # Validate login credentials based on user type
        query = f"SELECT * FROM users WHERE username = %s AND password = %s AND user_type = %s"
        cursor.execute(query, (username, password, user_type))
        result = cursor.fetchone()

        if result:
            student_name = result[3]
            dispatcher.utter_message(f"Login successful! Welcome, {student_name}")
        else:
            dispatcher.utter_message("Invalid credentials or user type. Please try again.")

        cursor.close()
        db_connection.close()

        return []



class ActionRetrieveResults(Action):
    def name(self) -> Text:
        return "action_retrieve_results"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        # Extract username from slots
        username = tracker.get_slot("username")

        # Connect to MySQL database
        db_connection = mysql.connector.connect(
            host="dev-mysql",
            user="root",
            password="",
            database="studentdb"
        )
        cursor = db_connection.cursor()

        # Retrieve results from database
        query = "SELECT * FROM results WHERE username = %s"
        cursor.execute(query, (username,))
        result = cursor.fetchone()

        if result:
            cgpa = result[2]  # Assuming cgpa is the second column in the results table
            dispatcher.utter_message(f"Your CGPA is: {cgpa}")
        else:
            dispatcher.utter_message(f"Results not found.Login First by saying Hi or Hello")

        cursor.close()
        db_connection.close()

        return []


class ActionRetrieveAttendance(Action):
    def name(self) -> Text:
        return "action_retrieve_attendance"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        # Extract username from slots
        username = tracker.get_slot("username")

        # Connect to MySQL database
        db_connection = mysql.connector.connect(
            host="dev-mysql",
            user="root",
            password="",
            database="studentdb"
        )
        cursor = db_connection.cursor()

        # Retrieve attendance from database
        query = "SELECT * FROM attendance WHERE username = %s"
        cursor.execute(query, (username,))
        result = cursor.fetchone()

        if result:
            attendance_percentage = result[2]  # Assuming attendance percentage is the second column
            dispatcher.utter_message(f"Your attendance percentage is: {attendance_percentage}")
        else:
            dispatcher.utter_message(f"Attendance not found.Login First by saying Hi or Hello")

        cursor.close()
        db_connection.close()

        return []


class ActionGeneralInfo(Action):
    def name(self) -> Text:
        return "action_general_info"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        # You can implement logic here to provide general information about the college
        dispatcher.utter_message(f"Here's some general information about the college...")
        return []


class ActionFacultyInfo(Action):

    def name(self) -> Text:
        return "action_it_faculty_info"

    def run(self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        faculty_name = tracker.get_slot("faculty_name")

        faculty_data = {
            "Chepuri Samson": {
                "description": "Dr. Chepuri Samson is a Professor in the IT Department. He holds a Ph.D. and has 24 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=14ckXGXbCv7WiNdxVxOkTXdVlSTIFFp7l'>"
            },
            "Jayasree Hanumantha Rao": {
                "description": "Dr Jayasree Hanumantha Rao.Designation : Professor,Qualification(s) : Ph.D,Email : jayasree_cse@mvsrec.edu.in,Area(s) of Interest : Network Security, Cryptography, Internet of Things, Block Chain Technologies, Machine Learning",
                "image": "<img src='https://drive.google.com/thumbnail?id=1K828DkmecplatjYdae7IV8uEM2TgIlkW'>"
            },
            "D. B. V. Ravi Shankar": {
                "description": "D. B. V. Ravi Shankar is an Associate Professor in the IT Department. He holds an ME (Ph.D) and has 25 years of total experience.",
                "image": "<img src='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQA8AMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAACAwQFAAEGB//EADoQAAIBAgQEAggEBgIDAQAAAAECAwARBBIhMQUTQVEiYQYUMkJScYGRI5KhsRUzYoLB0XLhJENzU//EABkBAQEBAQEBAAAAAAAAAAAAAAABAgMEBf/EACERAQEAAgICAwADAAAAAAAAAAABAhEDMRIhBBNBImFx/9oADAMBAAIRAxEAPwDlFQ6CxudqJImZMwAte3ibrTI5kBQupJRbC3hub1ot7SqDlbUqdda6vOAxlDquvlTQjshksMo3rZkkfKfhFgRUmMMkAQKxL66jSqiMYpMgYoQv2rDG62zIwvtUwc9nF4yQxtY7NToYps5AyIYgXAbWmhBhjeQnIua2/lRAd6kwpiCLWH4vi8Wl6U5YnM+5qpWgKIChWmi1GW1Go60zkuCLr7WwrEja9gpv2qRGJ5wcgvk/Si6KTCu+fwi61uPDmRWOY3XpR4kPhIDiJ2KoBc3aqqLHYnF3kwsCph+kst9fktTLKTtvHiyyvqLSCHOWDSZTbQHatzwJEoySq5tqoFVyYaWRyWxDMT9Kdi4sZgo+aqc2IDxW3Fc5zY26db8bOTabg7JnkMKS5Rs3SrCLEySJeNo4V6AqNarOH4jDyQrNGzhibFQdB86lTBCwErSDqMorr/jhrx7S+biwtzKpIv7QFRZ3klys8SDzUWvQrkJP48u3vClxoTJlDmx2oWtHTcWra3OoBIHUCpysWAULzSo97SgDyyBhzEjA921BDLUJIO4vW5MuozXIO9Aou4FwLnW9EGAvahdV7U4xhBIXYBkbReppngIYQx5s1rN8NFQWTpb6Uspepk7hpV5gOm570sFedmRSUU3tQJfCugBcMt6csEKEhYhKcuYFiQPsKLFYlJIFjFybliT+1ZHM0sis8nKyC103a9StKISxKHKxWOmXNY7d/M02FpBzsRCoCDQg62v0qO0e+RW+rXv8qmQTzQYRsMHSIO2ckC7GqAEUwg5hCqAdBbVqlDEJlj5RIkA3tSFxEaBlPNkuNCxt9K2kiPlTlIgvuNPuaIfnnymRWYqp3PQ0eGmllnOYB2fwlj0HkKyCNykmQeFjYZjYDzpOX1eVbMrFTe460Q+SPE5zIoJ5egvraowjkaQh2OYdDRiSVmYoxsTmsDWlmcT8w+J/OiWn4VeUbyxZ82gF6Zh4+TiRnT2dcopBmlmYADX+mnQREsryONXsVvqBVRNSRmnz8oqWBBvQYeRsPK/iyhjsNb0Ty4fmlkfw2It8qjSowZXIIzez3qrVX6QyetcUwnDh4EFpJBe5PYE1cmKNlChQAP0qilwcr+kDO4IZMpY+QFS39JOFQTGN58zXt4VJrwc27fT6nxtY4bq2hwcYIstrHYVd4OJXuMvh2NU0HEMPJhxLGwKEXuO1NwXpRwMSco4lxIN/AbVwkyterLLGKf0hgb0e40smGCjD4hLvGR4RrrarGIPyw/NiIOzFr6Uz0zwbYp8NiVKtBk0INxegheBYlQA5lGoO1fQ4unyvkyeRjm65HlgPmBSok9XlV2ZZFO9utDPKjsHSPLbS3etviEZgAgAA28666eU4zF0eOJLKWuGO4pfKjjUvJd9d+lAZCTba3QUySYvBkC2S9zahsqUSSxc3IAt7ACoxW5KsCDVnDJfDBFAIA8Q6/SowHPBWS2bo3+KBYkUeMJnbc3rT4mS4D6L1ValayfyIrEDK4qN6qWQshLvfVagPEyo8SqgDE7gdKOGaJbDlOBbVbe1SMKmXErdbWNjRpJJJnAdlkFyLUalRZmiEhCI4XqGNDIpUBgDlYDXpTHjXlh2k8R37005HwfidhGDZWIoOYUlrW36VNwwBjZkZQ17XY+yKhojaADU04BV0fa3UUVKxUiSFBH7Kra5Fix60tbDfasSPMgsOu9SGwyKtmlu29rVUHhJ+W9yA67ZTWYkKZ5Cost7gClFMhFrWqRDlKm58Vha9E7aw0iRliVvdSL01JYQgBhue9MhhiWSz3IA0FtKY0ETMzEsouLWHS1DSMsqrMGtlHX5U6WWOVLRR2IOjU1Fw6BlVS5Ite1baOOOMBQb3vtQ0QqxsLvmuD0FT8weJZHSQ5NjSSym+SHKtu1ISeaMg2OQHYimvRLJfaPGJMQ8sxILSoth2qnxvDMTiH8AjIBIssYAHYVe4KPlF79bD7bfpTMTKeWREBn+dfNuWUyr7OOOFkSPRHhrQ4ZsLiChZkbddATtVdwng/EcBxl0naNbAjMyAqWvofl5Vb+j3EE9ZCNHllynIpOh+tWmDxDz46VMQhAzXUMb7+dJuOlxxsM4hhfWeHRQHIlpRY28Iv2qoxkUcd8huAbX66aH9q6TjkRbCRZXyBJEYkHcA7DzO1cvj4pA4kawvoQOhr08FvlY8Xy5jMJf0p5YSVEaH596BiGa4AAo1wt2BZr3HepPLSLBu6W1Nq9T5pExKhVIHkR1oA5WMhRo3lTVcSx/jNYqNLCjEqsxjNvZulAvDEqCzC19q1Lf2x31A6Gm4y6xmx8OlrUpZQuV2/luLOOxop8DmRGMejXGby86CaZYwywbn2n70hlkgkKBrdiNiKwRsw08XyoFxytFJzN9xbvRuFg/luQ5HiHzosPHnm5T6G+lalCyma3tqb38hUWekcRAorXue1SMbHlitG3hB1Wh58WVQYr2XvQmZDNoOWnUd6i7UcckapJcEH3e9aLB1QP4iDc+QrWRXDCEMbai53X/dOiw6Muj2f4cpopmeLmiyLbS2tS5yjw3Rbnr5ComIWGMRmFgzKLOPOm4OKTEBlkm5cY0879BVSlvikaEJy/ED7Xeihkk8Kq1r0MeCOUyGRWQHodTUk4dY1DBTmG4zbCjJitI78pGJYHVr05wwVskpvcLe9QlkjW4yNfqQ1MWaIC3Kf81DaZCkjMVacCwvc1sxvmUesjOelCsN4EmWByHa3tVksSR5c0bX39r9KoKQFZHRpyoUaHuaXOCsaxmYsTvQPyQx5sUqm1wTQn1Y6nmj6US9Nxg3Zb3IqLMshl/DcqnXS5qcIkiiEqOzKTYX70FwrZ8oNeHlms/T6fx7fCbJ4dhJ/WkZWmIGpZWFx+ldMiYteKrnYSQSKCrAWZSOhqq4XOwxakL4RvXRxycyQZEVRtpWJXpoeMYt4UhiiKh2F2uL6dPreqLklZLOzMCLkE1M4tKI+IyZo2NlCqagTS8sMLk3GncV7OLHWO3yufPyyoBE7lnh1QbUxYWZVQvublaxI35LSK1h2FGZAsIcHx2tXXThpqSFSOWiHOdtaWmF0/F9rYU2T8FklMli4vYdBSbuIWkV7+PQH96aB4iNFwl1vrSILNeNtn/Q06WYyYQKQAQaSiK+XKxFh4vKinYfxERSC7pfIO/lQGTKLoDGy7gVmIIktInhZe3WmvlxEJl2dfaA/egjTkicup1Otx50kk3J2vv50Zv3vQE1ALA2vrY0O+ltalh4/V0UjxA0KNFzy3iCHbSiqdJZVljkndVdRlVEUX+vapAnKjmEWLtljt17mq/CoJp1A2J1Pyp8kolxMQXQKwC+QqRpgcBiSPeKkfWilZjiF5Vz10qPIPH9TToZljYlgTba1VmsQNzGWxve5FTY5cRNG8IFl2JI1qKcQebzgpV/ettUiLFESyswJV9KIWQ2fIVym9qmxYZTBIWbxj2daiNiXJa4Fz3G1TsC7YrJBE1pibWtVSdgwzzy5YYS5Ya5R0+lTpuEcTlCEwab72P610vDcDFgIckYu+7yAak1OdM6XGp6Hv8A6qbdPGfrkxwjiWJKiflxLb3j0+lz+1WkHBoRDkktOy7C1hVy65sOso7XP03pGIw7usiqSoZRqNxUu6skU3EYOFnC/wAO9bw8EntIA40bv/uuWZJoJHik8EqHK632Pl3B3roG9H0VTuJFNwRuCK3i8E2JwzRzRhsWi3ikBC5/K5/Y7Vy5cNzbtw8vjdXpUcPebmbD53q/TiEWGC2GeYmyoOprlxI8BYSRSxstwVdbFT2NXPo9w/EyTNjsRFY5csETDvux/b615cMcssnu5M8ePHdXON4dPxDh3NiAbGR+2t/bXy8x+1cu8U4lZJEZWXcPoRXacLjnK4x59czsqgC2Xtb7VLeLD41AJ4FYtpqNVPzr6Mmo+Tl/L24aKOUopa4RqLlr4194C4+VdG3o+0soXBYoIvVJhcKd9D2qsxvBOKYKORuQsqu386LxLb9xV3GdVU3uRmJta3yFEyBbANe+1qU+dHKuu1FHIFYEi4FGP07lFMM5OpzihaRcgRAbe8bVhxJUsFsVbWxooHLg3eNfK1TTRSeJwoGl+1TNMKM4AIY2I8qQrylzZVKjqFo5cQ2VQApW+oNBqSC8oEeqsLiobrYkGpgxViDkta4FqjSNmYkixNFKC61joytlI2o4yufxdK20w5rOBcNuD0qKpYfwcL/XLqP+P/dDhVDYlL/EKblXESh7hAykqp8tKyJVTER5Tds1y3l2o0TIPxGPYmsGtEyMznKCdelDYq1mUg+YoylQQGVkQaHepsXD9JFkzGRdiKjHwosoJsdLjpRCaZFMiykdN9aqNNCRGXaVSx92+tdL6LYcDNMwK5VsL9z/ANVzsUQa5k9pwSK6b0VlzYCQEXyyC/2qVcZ7X6EW02qZh47+yPFuR0YVAGuo27VNwgZGVoxmS+oB1FSOlZJkRzGpOVtbH3SalcsFUU+8Cp+1L4qqqiYhRa+9aWW7G59kKf0rWmQiJZY1bW7C1+xFRJ8KpIDDR9j8LCrCDVXTqpzLW8ZFfDFl1KEOPpvRa5mXg8ePxsUzgosGs39Y90ff9jV1GgRUIAAvcAUMUfLw8/ivmnYX8gq2/wA/eiV8yQ2+RqYyY9JbcvVGl0gQLuzZjWzFzGZU62Za0NRGB1uP1p0QKlZBoUuPtRZ6DCwCrO++U5/Op2Cl5iWta+wGwqq4g4jlECHY7eW9TeGuTtTRHJenHBv4fio8Xh1/8Wfw2+B+3ytXNCvXeNYGPH8DxOHlFyELK3ZhqK8kyHQDttTFz5MdVqsX2hTBh5DqdB3NPw2HiBztJcKdRWmNI+d4yd1v5Vp5DINTe1ScTLC05tFp0NR8TGsao0Zur7U0um73FLY1oNQk1FOhQSOVOgynWhaE2JTUAA60tZCt7dRageV2vc26G1RUFJpGBBlWcgGwy2tW45o4JPxYYzIN8p2quBB0zWJ3y9aaZOZlzjxDQt3o2eJXykq3vXHlTGxM0qhZGDW7rrUdLBSNb0Q3oylzSoUjSFSFGrA96kYQYYWMr/idLjQVDjW432oiNdhVZWUOGl9ZWUOkyX1KHb6VeeiigJiEvrn1FcpDI8T54zlYbEaV0XotMzS4gk2crmpY1j26hBlN7fapuFGuaE+LqO/kagxFydbVYYdQTeMgSWubbfWsx0o+PSL/AAdnX2iw8Ntb9RUBZLyeRVb/AGFWHE0JSKYC5WzgdMy/9Xqhw8rCwcHQZftcVZfei4fx3F1CTmzDr+1THK8rXbrVfC1lGtPmkth3+Va0yiHwwBOxIPzAt/ilI1ol7g1hcnmf/T9wD/mkoxsAe9ZIm4aWPmRh2sAG371JeRFjmIYGzX371WSJ4T8XSswWLEMLkBWdlIynqBQ2RHN6xjJ5CbhSE08hV7w/KqZmIt3Nc7wxw6M6gZWkYg99av8AAKlhnJYX0XoP90WLrDlpkuVtCt9SPb/6ryziKeq8RxMcSqFSRhcb716g0/MVoYdXItcbL868w9JRyuP41QbZZLHzNqY9pydRXSsras7XvtRvlEaLm0IvSziI28MqW/qFPSESwKUYG21+tbc4WIxOqXa2tKxZywQKDte3yvWykksmRVIH7UrFsJJ7KfBHZV+lQADpWiwtem4Qxo0hktbJoD1NYhEwK8sBgNLUqoxamGPmqpRTm7d6L1cD+bOi/Ktc/Kc4a7KbCsrFIIze+Q/aiWJtTY/Y16MOGP8A/qn5RRrw6b44/wAlR18HnSxv8DflNEIZCdEb8pr0gcPm+OP8tGvD5+jxn+2m0+t5ysEhtdWH0NO5JUdfsa9DGAn97lH+2t/w+YDTlflq7T63nqIbeyfsas/R8tFxJcwYK4K7V2K8PmG5i/LR/wAPmAuBH8wKWrOPSOWtrf8AWpWCJWRWe/LG4vYNUJwVJVtxvW4XeP2W07GpCuiWVcYMjg8hdcx8IqtxHC1ztPDiCI7ksXGhJ6CtDFgxqjEkD3R1p8U1mWXFG2XVE7fMVdfqb9aCmCxcWHhMkZuLg2O9Y/MELgxsDsAetPl4pGX8bXPTSlM8mJKm2VF1161dmkKNZDnCxuSuUsMvs6Aa/alEOt86MADuRauihxGESN0QxrLIfEWI8VJxuC5UYkgZbPsNie+tQ0ppuey54oZWUG4ZUJB+1UPEMQ2GVJJUlhzAqrupX6a13fClOGMiyKQjWIpXHUw2MwkkM4V0ca5uhqUkjkvR6bm4CJlGpJ8P9xro8KouOc1kPQGuY9HYJxw6NeW6ZcwIy6mx0HyrpuHsryquIhfMfZZrW+tIXt0GCeMpaEDKDYkV5l6bwyJ6SYvKpIZg1wO4r1HDrkARVAXc5dqquK4YyY1mAjtYaka7VJdVq4+UeS8uT4HP9pqTFLOkeQQuQP6a9F9Tb+j7VsYRv6PtW/JmcX9vNf8AySLFJbf8aWYpR/6ZPy16acK/ZPtQthZenLHzWmz6nmfKl0/Cf6qa2IZL35b7fCa9J9WlHvR/loGw0vxxflqWr9bzg4eTpFJ+SkyQzD/0SH+w16Q2GxHxx/kqLHhceXHMniydbJrU2s40kUxd6WtqYDUdDRRilqaMGgMUW9ADRXoDFGuhvSwaMGgp+JpycSSPZcZh86jo996suMqpwTOdOXreqKKYGrHPLtZxSBDe1zTs5fVrDzNQFxAQedSIZlcXJremKlJIl7KoPmRTCFYeKo0TodB36VK5kKKTcCw946VUpUmGw7ixjU37iihVsGv4GJdF6INV+1In4vhYwRGDO3aIaffaoUmNmxS2J5MfVV3P1p6Ta0l42ApUkPJsFX/NQ2mEkgfEHXpobCoqRxxCyoLHzsfvUhHGyzFT8LrcfesNaSoYVm1jkV7fCdRU7Do2zctwuhuutQEjLgF40J+KN7Gp0OIkQBZbygdWGVh/utQXWDAUeHQdhSMUfxm7imYF1ceE3FR5mvISd7mudnt1wavWr+dDetE0abNCay9CTQaNAbVstQE0AtQHc6miJpbNSqiLRit1lVBKaYtZWUBijFZWVBvrRCsrKorfSMkcMZQbAkXrngLSFRoAtZWVXPLs0MfD1160GIxUkKFkC3He9ZWVL0Y9n4aaR8NG5axZQTamWzqM7M2vU1lZW3O9o8CiNXyaWYkW6VOMYWBJ0JV3XxAbH6VlZUQWG/EB1y/KhLWkIAArKyqo85vewv3qZBJIBpI33rdZRaueGSsV1tWE337msrKmTfG11oTWVlZdGqE1qsqAGoGrKygBjSWJrKylV//Z<'>"

            },
            "A V Krishna Prasad": {
                "description": "Dr. A V Krishna Prasad is an Associate Professor in the IT Department. He holds a Ph.D. and has 24 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1enjJ5uNwUuYjv5CTHFsG7WTYXt10L-xE'>"
            },
            "Bande vasavi": {
             "description":"Dr. Vasavi Bande is an Associate Professor with a Ph.D. in her field. Her areas of interest include Cloud Computing, Cryptography and Network Security, Artificial Intelligence, and Machine Learning. She teaches a variety of subjects at the undergraduate level such as Data Structures, AI, ML, Operating Systems, C Programming, Cloud Computing, Web Technologies, Design and Analysis of Algorithms, and Computer Organization. At the postgraduate level, she teaches Cryptography and Network Security, Machine Learning, Software Project Management, and OOAD. You can reach her at vasavi_it@mvsrec.edu.in.",
             "image":""
            },
            "Jindam Sowjanya": {
                "description": "Jindam Sowjanya is an Assistant Professor in the IT Department. She holds an M.Tech and has 22 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=15-VZ-cUY4oRRHlY0DZIwJdFV6t5F9_oD'>"
            },

            "Kuthadi Devaki": {
                "description": "Kuthadi Devaki is an Assistant Professor in the IT Department. She holds an M.Tech and has 21 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1Z8raMpkFU33KfogSeHFcwP-R-Anj_y7D'>"
            },
            " Vijaya Bhaskar": {
                "description": "Seelam Ch Vijaya Bhaskar is an Assistant Professor in the IT Department. He holds an M.Tech and is pursuing a Ph.D., and has 20 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1512SWzO9DELSOFEyMveAARknRiRmnxUb'>"
            },
            "Gumpally usha sri": {
                "description": "Gumpally Usha Sri, an Assistant Professor with an M.Tech degree, has areas of interest in Big Data and Cloud Computing. She teaches several undergraduate courses including Programming in C, C++, Data Structures, Discrete Mathematics, Java Programming, Mathematical Foundation of Information Technology, and Design & Analysis of Algorithms. You can contact her at ushasri_it@mvsrec.edu.in.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1ikDc1-0k6yDBiAQESf0ie6WFSSIclcH9'"
            },

            "Kakara Sri Lakshmi": {
                "description": "Kakara Sri Lakshmi is an Assistant Professor in the IT Department. She holds an M.Tech and is pursuing a Ph.D., and has 18 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1XWhHxNNaw1kGZfKjPYaG0xGYeAP8fSwt'>"
            },
            "Pisupati Karthik": {
                "description": "Pisupati Karthik is an Assistant Professor in the IT Department. He holds an M.Tech (CSE), MBA (HR), (Ph.D), and has 14 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1lKZnUTZ4csXGg93ze9yaZD4_fBn8CoSg'>"
            },
            "Kintali Chandra Sekhar": {
                "description": "Kintali Chandra Sekhar is an Assistant Professor in the IT Department.He holds an M.Tech, (Ph.D), and has 17 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1vlxbdRf3qQCwqgD7g5LBX2iU1_urATHx'>"
            },
            "Chikkela Srujana": {
                "description": "Chikkela Srujana is an Assistant Professor in the IT Department. She holds an M.Tech and is pursuing a Ph.D, and has 17 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1OihqEqw3pbKhxjRS_7zrPI0OD1bSP2mQ'>"
            },
            "Durgam Muninder": {
                "description": "Durgam Muninder is an Assistant Professor in the IT Department. He holds an M.Tech, (Ph.D), and has 12 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1Ey2vzis1GP3aaVEYSZk4qjAKkqaM59O6'>"
            },
            "Annapureddy Manasa": {
                "description": "Annapureddy Manasa is an Assistant Professor in the IT Department.She holds an M.tech, and has 13 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1wdScFpDNA_ykIVFEFSfCwfDNb3o6fm1w'>"
            },
            "Parlakula Amba Bhavani": {
                "description": "Parlakula Amba Bhavani is an Assistant Professor in the IT Department.She holds an M.Tech, and has 15 years of total experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1l9xm2amWAoyotVhhOD3p_A5-NkLjKQ88'>"
            },
            "B. Kalpana": {
                "description": "B. Kalpana is an Assistant Professor in the IT Department.She holds an M.Tech, and has 3 years of experience.",
                "image": ""
            },
            " P. Sita Sowjanya": {
                "description": "P.Sita Sowjanya is an Assistant Professor in the IT Department.She holds an M.Tech, and has 3 years of experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1VMI53Yek_N4ML9M0kvDomCtc5l-nVGks'>"
            },
            "T. Shashi Kumar": {
                "description": "T. Shashi Kumar is an Assistant Professor in IT Department.He holds an M.Tech (CSE), and has 10 years of experience.</a>",
                "image": "<img src='https://drive.google.com/thumbnail?id=1f1XJ4N8TXkU6d0HXjzTKfz9HN0Z3TfJ1'>"
            },
            "Medishetty Swapna": {
                "description": "Medishetty Swapna is an Assistant Professor in IT Department.She holds an M.Tech (DSCE), and has 16 years of experience.",
                "image": ""
            },
            "p. sita sowjanya": {
                "description": "P. Sita Sowjanya is an Assistant Professor with an M.Tech degree. Her areas of interest are Artificial Intelligence, Machine Learning, and Data Science. She teaches undergraduate courses such as Machine Learning, DBMS, and Software Engineering. You can reach her at sitasowjanya_it@mvsrec.edu.in.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1VMI53Yek_N4ML9M0kvDomCtc5l-nVGks='"
            },

            "Maya B. Dhone": {
                "description": "Maya B. Dhone is an Assistant Professor in IT Department. She holds an M.Tech (SE), and has 16 years of experience.",
                "image": ""
            },
            "M. Prathyusha": {
                "description": "M. Prathyusha is an Assistant Professor in IT Department. She holds an M.Tech, and has 7 years of experience.",
                "image": ""
            },
            "Sri Laxmi K": {
                "description": "Sri Laxmi K is an Assistant Professor in IT Department.She holds an M.Tech, (Ph.D), and has 24 years of experience.",
                "image": ""
            },
            "M. Sravani": {
                "description": "M. Sravani is an Assistant Professor in IT Department.She holds an M.Tech, and has 12 years of experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1uLW1Mm3qHUJiOJOJf7D1TuGo-dIwsnpr'>"
            },
            "Thuvva Anjali": {
                "description": "Thuvva Anjali is an Assistant Professor in IT Department.She holds an M.Tech, (Ph.D), and has 6 years of experience.",
                "image": ""
            },
            "B. Mahender Reddy": {
                "description": "B. Mahender Reddy is an Assistant Professor in IT Department.He holds an M.Tech, and has 11 years of experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1UG3GQCfjIMd3LtJRC_pLTKn7Hb2ooeh0'>"
            },
            "Nithya Lakshmi": {
                "description": "N. Nithya Lakshmi,Designation : Assistant Professor,Qualification(s) : M.Tech(CSE),and has 15 years of experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1CNurOyiJe1UnkeuYED9ZeSSZ0N57_VHN'>"
            },
            " Korukonda Ramya Madhavi": {
                "description": "Korukonda Ramya Madhavi,Designation : Assistant Professor,Qualification(s) : M.Tech, and has 13 years of experience.",
                "image": "<img src='https://drive.google.com/thumbnail?id=1zW12B4H0_PaMCyTwdpIfjkOxyDuTGwTv'>"
            },
            "Jettipalle Prasanna Kumar": {
                "description": "Jettipalle Prasanna Kumar, Professor and HoD [TPO] at MVSREC since 1988, specializes in Software Engineering and Computer Networks. An award-winning educator, he has been the Placement Officer since the college's inception,and has 39 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1fqTdBqTXGlvxWdpSsG88x9BvX1yYMyrw'>"
            },
            "Dr Akhil Khare": {
                "description": "Dr. Akhil Khare, a Professor at MVSREC, specializes in Artificial Intelligence and Cloud Computing. He teaches various subjects at both UG and PG levels, including AI, Cloud Computing, and Network Security,and has 19 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1eXvUTLpzE4e0qqGRgdLiRDVRiI7BRL45'>"
            },
            "Dr Sesham Anand": {
                "description": "Dr. Sesham Anand, a Professor at MVSREC, specializes in Artificial Intelligence, Neural Networks, and Deep Learning. He teaches various subjects at both UG and PG levels, including AI, Machine Learning, and Data Mining,and has 22 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1lCV4w_dxezzI2wDNoMYSfO7yKqpyFrpW'>"
            },
            "Dr Banda Sandhya": {
                "description": "Dr. Banda Sandhya, a Professor at MVSREC, specializes in Machine Learning, Deep Learning, and Image Processing. She teaches subjects such as AI and Algorithms at the UG level and AI and Advanced Operating Systems at the PG level, and has 19 years of experience."
            },
            "Dr Sanjeev K Yadav": {
                "description": "Dr Sanjeev K Yadav, an adjunct professor at MVSREC and holds an P.hD, and has 33 years of experience.",
                "image": ""
            },
            "Meduri Anupama": {
                "description": "Meduri Anupama, an Associate Professor at MVSREC, specializes in Automata Languages & Computation, Compilers, and Artificial Intelligence. She teaches a wide range of subjects at the UG level, including Data Structures, AI, and Computer Networks, and has 29 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1aLgYWok2z0p6FztgF314SABGS1iQTdhC'>"
            },
            "Godavarthy Vijay Kumar": {
                "description": "Godavarthy Vijay Kumar, an Associate Professor at MVSREC and CISCO NetAcad Contact, holds an M.Tech and is pursuing a Ph.D, and has 48 years of experience.",
                "image": ""
            },
            "Bantu Saritha": {
                "description": "Bantu Saritha, an Associate Professor at MVSREC, specializes in Artificial Intelligence, Machine Learning, and Cyber Security. She teaches a variety of subjects at both UG and PG levels, including Cyber Security, AI, and Advanced Databases, and has 24 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=113nmzboY0Pu0KYzmmpUqRVfQVB3VZAQ1'>"
            },
            "Mohammed Abdul Azeem": {
                "description": "Mohammed Abdul Azeem, an Associate Professor at MVSREC, specializes in Wireless Sensor Adhoc Networks, Network Security, and Algorithms. He teaches a wide range of subjects at both UG and PG levels, including Data Structures, Computer Networks, and Advanced Algorithms, and has 25 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1SsHLjLaIROKJwspWogHQtGmLN5kESdCu'>"
            },
            "Dr Rajesh Kulkarni": {
                "description": "Dr. Rajesh Kulkarni, an Associate Professor at MVSREC, specializes in Data Science, Machine Learning, and Software Engineering. He teaches a diverse range of subjects at both UG and PG levels, including Artificial Intelligence, Software Engineering, and Research Methodology,and has 28 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1eryPGGoy_bBm6ITTITUc3vKXSwD77Mqb'>"
            },
            "Dr Daggubati Sirisha": {
                "description": "Dr. Daggubati Sirisha, an Associate Professor at MVSREC, specializes in Image Processing, Computer Vision, and Machine Learning. She teaches Image Processing and Machine Learning at the UG level and Embedded Systems and Image Processing at the PG level, and has 20 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1Ak3lI3TBfVrVluGiHFaeIX_lISm17Wf3'>"
            },
            "Dr Yarlagadda Madhulika": {
                "description": "Dr. Yarlagadda Madhulika, an Associate Professor at MVSREC, specializes in Text Mining, Information Retrieval Systems, and Natural Language Processing. She teaches a diverse range of subjects at both UG and PG levels, including Programming, NLP, and Advanced Computer Architecture,and has 15 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1Eyf-vlBvyvZBFs2tq-V8BBtEDmKbRLJs'>"
            },
            "Dr Namita Parati": {
                "description": "Dr. Namita Parati, an Associate Professor at MVSREC, specializes in Artificial Intelligence, Machine Learning, and Cyber Security. She teaches a wide range of subjects at the UG level, including Data Science and Software Engineering, and Artificial Intelligence at the PG level,and has 15 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1SZK7NsqylPUV-tq3N3Ps-zEDENlAUIp_'>"
            },
            "Dr. K. Shyam Sunder Reddy": {
                "description": "Dr. K. Shyam Sunder Reddy, an Associate Professor at MVSREC, specializes in Artificial Intelligence, Machine Learning, and Data Mining. He teaches various subjects at both UG and PG levels, including AI, Machine Learning, and Information Security,and has 14 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1gRDrTO_dmdR1oVn7Pn7kMZRGW-Z0Upw3'>"
            },
            "Dr. Vemula Sridhar": {
                "description": "Dr. Vemula Sridhar, an Assistant Professor and TPO at MVSREC, specializes in Cloud Computing and Web Application Development. He teaches various programming and computer science subjects at the UG level and Cloud Computing at the PG level,and has 19 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1GY3dtPTXx6r032ZJQLDg8qFGkebLyIT3'>"
            },
            "Ambati Saritha": {
                "description": "Ambati Saritha, an Assistant Professor at MVSREC, specializes in Data Mining, Machine Learning, and Algorithms. She teaches programming languages and Data Structures at the UG level,and has 18 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1Pok0u8nFiHvzi1jjmn9qwMsUN-YmHhxX'>"
            },
            "Pallikonda Subhashini": {
                "description": "Pallikonda Subhashini, an Assistant Professor at MVSREC, specializes in Cloud Computing, Network Security, and Machine Learning. She teaches a variety of subjects at the UG level, including Data Structures and Cloud Computing, and Distributed Computing and Advanced Data Structures at the PG level,and has 20 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1Ul4RT8pvdlFGjkk8gEeW0mdyub6hJj_P'>"
            },
            "Battula Venkataramana": {
                "description": "Battula Venkataramana, an Assistant Professor at MVSREC, specializes in Machine Learning and Natural Language Processing. He teaches Data Mining, DBMS, and various programming courses at the UG level and Data Mining at the PG level,and has 17 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1WGQPiF2J4zyWt4j4yIdtu7JUo0HZoytm'>"
            },
            "Marneni Dyna Balraj": {
                "description": "Marneni Dyna Balraj, an Assistant Professor at MVSREC, specializes in Machine Learning, Big Data, and Graph Theory. She teaches a variety of subjects at the UG level, including Discrete Mathematics, Web Programming, and Software Engineering,and has 17 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1gqJcJpOL09FtfBTi2FT2H2f6Jlhs1nQO'>"
            },
            "Boddupally Janaiah": {
                "description": "Boddupally Janaiah, an Assistant Professor at MVSREC, holds an M.Tech and is pursuing a Ph.D. His areas of interest include various domains within computer science,and has 19 years of experience."
            },
            "Nagamala Sabitha": {
                "description": "Nagamala Sabitha, an Assistant Professor at MVSREC, specializes in Spatial Mining, Computer Networks, and AI & Machine Learning. She teaches various subjects at the UG level, including Java and DBMS, and Mobile Computing and Distributed Computing at the PG level,and has 16 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1D6Y0ZGjQHYeoRlGNQBzd2Bvln40p1T5V'>"
            },
            "Damarla Haritha": {
                "description": "Damarla Haritha, an Assistant Professor at MVSREC, specializes in Machine Learning and Deep Learning. She teaches a variety of subjects at the UG level, including Java and DBMS, and Advanced Operating Systems and Cloud Computing at the PG level,and has 19 years of experience."

           },
           "Tiruvayipati Sujanavan": {
                "description": "Tiruvayipati Sujanavan, an Assistant Professor at MVSREC, specializes in IoT, HCI-Sec, OS, and Cloud Computing. He teaches Software Engineering, Operating Systems, and IoT at the UG level, and Cloud Computing and IoT at the PG level,and has 13 years of experience."
                               "<img src='https://drive.google.com/thumbnail?id=1uJkJF4bdqr2URgChw-tgbQASgB1BilsH'>"
           },
           "K Padma": {
            "description": "K Padma, an Assistant Professor at MVSREC, specializes in Natural Language Processing and Speech Recognition. She teaches a variety of subjects at the UG level, including Programming in C, C++, and Data Structures, and Algorithms,and has 17 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1Gkx8iUBLyIyLzW27Qk0oxH0kvU3zyq5v'>"
            },
           "Sathish Vuyyala": {
            "description": "Sathish Vuyyala, an Assistant Professor at MVSREC, specializes in Machine Learning. He teaches various subjects at the UG level, including Programming Languages and AI, and Web Technologies and Software Project Management at the PG level,and has 16 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1mDeOFp5TZCQO7cb8mdK_Lqb1pC2yrsj1'>"
            },
            " Dr. M. V. R. Jyothisree": {
            "description": "Dr. M. V. R. Jyothisree, Assistant Professor with a Ph.D., specializes in IoT, AI, ML, and Network Security. She teaches various subjects at UG and PG levels, including DBMS, SE, Network Security, and more,and has 14 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1H6081cP8uR4OSa4AArP7AOmbKDx4sF1a'>"
           },
           "Vikram Narayandas": {
            "description": "Vikram Narayandas, Assistant Professor and CISCO NetAcad Instructor with an M.Tech (Ph.D.), specializes in MANET, IoT, computer networks, and security. He teaches Computer Networks, Mobile Computing, and Information Security at UG and PG levels,and has 18years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=17GP-V_tb8myQXb4qlp53OY9mHbenemAK'>"
           },
           "Thimmareddy Lakshmi": {
            "description": "Thimmareddy Lakshmi, Assistant Professor with an M.Tech (Ph.D.), focuses on ML, AI, and MANETs. She teaches diverse subjects at the UG level, including DIS, LST, and DC,and has 12 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1Xij1EkezumbDTfEmg7o5DRSeXv47mAG1'>"
           },
           "Methuku Madhuri": {
           "description": "Methuku Madhuri, Assistant Professor with an M.Tech (Ph.D.), specializes in Deep Learning and Natural Language Processing. She teaches Compiler Construction, Computer Organization, and Operating Systems at the UG level and Software Project Management at the PG level,and has 13 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=15bDehABh3qFpkhNbJ1hkCZ3dEDcp0cEn'>"
           },
           "Kanajam Muralikrishna": {
            "description": "Kanajam Muralikrishna, Assistant Professor and CISCO NetAcad Instructor with an M.Tech (Ph.D.), focuses on SDN and IoT. He teaches a wide range of subjects at the UG level, including Computer Networks, Distributed Systems, and Information Security,and has 15 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1EsCPyPJJ-HWzpGRg7pb0NPC2ahwTSr8p'>"
           },
           "Pothavarjula Phani Prasad": {
            "description": "Pothavarjula Phani Prasad, Assistant Professor and Wipro Certified Faculty with an M.Tech, specializes in Java, Web Programming, and Blockchain Technologies. He teaches a variety of UG subjects, including OOP using Java, Web Programming, and Artificial Intelligence,and has 13 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1Gd9c1y5EmoEz3WS9yVQcH0BpdcrInn62'>"
           },
           "Barige Ranjith Kumar": {
            "description": "Barige Ranjith Kumar, Assistant Professor with an M.Tech, specializes in Programming and Algorithms. He teaches various UG and PG subjects, including Data Structures, Operating Systems, and Design Patterns,and has 19 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1fGMONoSiqiY2qo0yXhBt5eKFEkZIyf4k'>"
           },
           "Gummedelli Srishailam": {
            "description": "Gummedelli Srishailam, Assistant Professor and Wipro Certified Faculty with an M.Tech, focuses on Web Technologies, Machine Learning, and CryptDB. He teaches a range of UG subjects, including DBMS, OOPS with Java, and Web & Internet Technologies,and has 21 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1RDjXWKaUBH6EQ1kffulkghnedWTIwCvp'>"
           },
            "Kagolanu Venkata Sri Lakshmi Asharani": {
            "description": "Kagolanu Venkata Sri Lakshmi Asharani, Assistant Professor with an M.Tech (Ph.D.). She is dedicated to teaching and research in her field,and has 14 years of experience."
           },
           "Tigulla Srikanth": {
           "description": "Tigulla Srikanth, Assistant Professor with an M.Tech, specializes in Cloud Computing and OOP using Java. He teaches Discrete Mathematics, OOP using Java, and more at the UG level,and has 12 years of experience."
           },
            "Kanala Kavitha Lakshmi": {
            "description": "Kanala Kavitha Lakshmi, Assistant Professor with an M.Tech (Ph.D.), specializes in Image Processing and Machine Learning. She instructs a variety of subjects at the UG level, including Data Mining, Software Engineering, and Web Programming,and has 18 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=112ShT5gPUfDPJODL7cIm5uDoLO6EmHFd'>"
           },
           "Godala Madhu": {
            "description": "Godala Madhu, Assistant Professor with an MIT (M.Tech) qualification, specializes in Software Testing. He teaches Programming in C and C++ at the UG level and subjects like Data Communication and DBMS at the PG level,and has 24 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1TCPqm1-gdzmxgjB-jr1jcU0niOAZT32N'>"
            },
            "Inala Navakanth": {
            "description": "Inala Navakanth, Assistant Professor with an M.Tech (Ph.D.), specializes in Bioinformatics and Language Processing. He teaches subjects like Compiler Design and Operating Systems at the UG level and Advanced Operating Systems at the PG level,and has 17 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1_uJrCwAvC5uu-zgU8p-hBnk14C-tPxSP'>"
            },
           "Neelakanta Rao Piratla": {
            "description": "Neelakanta Rao Piratla, Assistant Professor with an M.Tech, specializes in Machine Learning, DBMS, and OS. He teaches DBMS, SE, and other subjects at the UG level and Data Analytics at the PG level,and has 7 years of experience."
                           "<img src='https://drive.google.com/thumbnail?id=1uw0u7A1rWnvr3AXhGWgsAyKRQ1ZLi0ds'>"
            },
            "B. Sneha": {
            "description": "B. Sneha, Assistant Professor with an M.Tech, specializes in [Area(s) of Interest)]. She is committed to teaching and research in her field,and has 2 years of experience."
             },
            " S. Joshua Johnson": {
            "description": "S. Joshua Johnson, Assistant Professor with an M.Tech (Ph.D.), specializes in [Area(s) of Interest)]. He is dedicated to advancing knowledge and fostering learning in his field,and has 11 years of experience."

             }

        }

        if faculty_name and faculty_name in faculty_data:
            faculty_info = faculty_data[faculty_name]
            description = faculty_info["description"]
            image_url = faculty_info.get("image", "")
            message = f"{description}"
            if image_url:
                message += f"\n{image_url}"
        else:
            # Use fuzzy matching to find the best match
            faculty_names = list(faculty_data.keys())
            match = process.extractOne(faculty_name, faculty_names, score_cutoff=50)

            if match:
                best_match_name = match[0]
                faculty_info = faculty_data[best_match_name]
                description = faculty_info["description"]
                image_url = faculty_info.get("image", "")
                message = f"{description}"
                if image_url:
                    message += f"\n{image_url}"
            else:
                message = "Sorry, I don't have information about this faculty member."

        dispatcher.utter_message(text=message)

        return []


class ActionAskFacultyId(Action):
    def name(self) -> Text:
        return "action_ask_faculty_id"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        user_type = tracker.get_slot("user_type")
        if user_type == "visitor":
            dispatcher.utter_message("Welcome to MVSR! We're here to assist you with any questions you have—no login required for visitors!")
            return []
        dispatcher.utter_message("Please provide your faculty ID.")
        return []


class ActionAskFacultyPassword(Action):
    def name(self) -> Text:
        return "action_ask_faculty_password"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        dispatcher.utter_message("Please provide your password.")
        return []


class ActionValidateFacultyLogin(Action):
    def name(self) -> Text:
        return "action_validate_faculty_login"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        faculty_id = tracker.get_slot("faculty_id")
        faculty_password = tracker.get_slot("faculty_password")

        db_connection = mysql.connector.connect(
            host="dev-mysql",
            user="root",
            password="",
            database="facultydb"
        )
        cursor = db_connection.cursor()

        query = "SELECT * FROM faculty WHERE faculty_id = %s AND faculty_password = %s"
        cursor.execute(query, (faculty_id, faculty_password))
        result = cursor.fetchone()

        if result:
            faculty_name = result[1]
            dispatcher.utter_message(f"Login successful! Welcome, {faculty_name}.")
        else:
            dispatcher.utter_message("Invalid credentials. Please try again.")

        cursor.close()
        db_connection.close()

        return []


class ActionCheckHoliday(Action):
    def name(self) -> Text:
        return "action_check_holiday"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: DomainDict) -> List[Dict[Text, Any]]:

        # Retrieve the date from the slot
        date_str = tracker.get_slot('date')

        # Check if the date is provided
        if date_str is None:
            dispatcher.utter_message(
                text="Please provide a date in the format DD/MM/YYYY or say 'today' or 'tomorrow'.")
            return []
        # Handle specific phrases like "today" and "tomorrow"
        if date_str.lower() == "today":
            date_obj = datetime.today()
        elif date_str.lower() == "tomorrow":
            date_obj = datetime.today() + timedelta(days=1)
        else:
            # Attempt to parse the date string to a datetime object
            try:
                date_obj = datetime.strptime(date_str, '%d/%m/%Y')
            except ValueError:
                dispatcher.utter_message(text="The provided date format is incorrect. Please use DD/MM/YYYY.")
                return []

        # Get the day of the week
        day_of_week = date_obj.strftime('%A')

        # Check if the date falls on a Saturday or Sunday
        if day_of_week in ['Saturday', 'Sunday']:
            dispatcher.utter_message(text=f"Yes, {date_obj.strftime('%d/%m/%Y')} ({day_of_week}) is a holiday.")
        else:
            dispatcher.utter_message(text=f"No, {date_obj.strftime('%d/%m/%Y')} ({day_of_week}) is not a holiday.")

        return []


class ActionProvideContactInfo(Action):

    def name(self) -> Text:
        return "action_provide_contact_info"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        message = ("For any information, you can call 098490 19240. "
                   "For further detailed information, you can visit this <a href='https://mvsrec.edu.in/index.php?option=com_content&view=article&id=684&Itemid=1276' target='_blank'>contact us</a>.")
        dispatcher.utter_message(text=message)

        return []


class ActionAchievements(Action):

    def name(self) -> Text:
        return "action_achievements"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        achievements_text = (
            "Here are some achievements of MVSR college:\n"
            "- IEEE MVSR students selected as Student Network Members, 2020-21.\n"
            "- CSI-MVSR Student Branch wins 8 National Awards.\n"
            "- AIR 10th Rank in SAE BAJA-2019.\n"
            "- \"IEEE-Emerging Student Branch Award\".\n"
            "- 11th SAE-Convention Awards.\n"
            "- ACM Headquarters recognition for MVSR ACM Student Chapter.\n"
            "- ME Alumni create corona protective gear - Daava 3D Printing Services.\n"
            "- EEE Students won 1st place in Technocity (Project Expo) at Osmania University.\n"
            "- Taekwondo team won multiple medals in Inter College Tournament.\n"
            "- IEEE MVSR Student Branch won International Darrel Chong Award- Gold in 2017."
        )

        dispatcher.utter_message(text=achievements_text)

        return []


class ActionListCompanies(Action):

    def name(self) -> Text:
        return "action_list_companies"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        companies = [
            "Infosys",
            "Wipro",
            "Amazon",
            "Flipkart",
            "Pegasys",
            "Ashoka Constructions",
            "Anasol",
            "MG Motors",
            "Toyota",
            "HCL",
            "Deloitte",
            "Modak Analytics",
            "IBM",
            "Medha",
            "Capgemini",
            "Cisco"
        ]
        companies_list = "\n".join(f"- {company}" for company in companies)
        response = f"The companies that visit MVSR for placements include:\n{companies_list}"

        dispatcher.utter_message(text=response)
        return []


class ActionShowTimetable(Action):
    def name(self) -> Text:
        return "action_show_timetable"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        faculty_id = tracker.get_slot("faculty_id")

        try:
            # Database connection setup
            db_connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="facultydb"
            )
            cursor = db_connection.cursor()

            if faculty_id:
                query = "SELECT * FROM faculty WHERE faculty_id = %s"
                cursor.execute(query, (faculty_id,))
                result = cursor.fetchone()

                if result:
                    guest_faculty = result[1]
                    # URL encode the faculty name
                    guest_faculty_encoded = urllib.parse.quote(guest_faculty)
                    timetable_image_url = f"http://127.0.0.1:5000/images/timetables/{guest_faculty_encoded}.jpg"

                    # Send a message containing the URL to the image
                    dispatcher.utter_message(text=f"Timetable for {guest_faculty}")
                    dispatcher.utter_message(image=timetable_image_url)
                else:
                    dispatcher.utter_message(
                        text="Faculty ID does not exist. Please check the faculty ID and try again.")

        except mysql.connector.Error as err:
            # Handle database errors
            dispatcher.utter_message(text=f"An error occurred while fetching the timetable: {err}")
        finally:
            # Close the cursor and database connection
            if 'cursor' in locals():
                cursor.close()
            if 'db_connection' in locals() and db_connection.is_connected():
                db_connection.close()
            return []


class ActionProvideHodDetails(Action):

    def name(self) -> Text:
        return "action_provide_hod_details"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:

        entities = tracker.latest_message.get("entities", [])
        print("Extracted entities:", entities)

        department = tracker.get_slot('department')
        print("Department slot value:", department)
        hod_details = {
            "CSE": {
                "name": "J. Prasanna Kumar",
                "image": "<img src='https://mvsrec.edu.in/images/all_img/J.-PRASANNA-KUMAR.jpg'>",
                "description": "He has been working with the college since 1988, having joined as assistant professor. He bagged the best teacher award instituted by the MECT three times. He has one year of Industrial experience before joining our college.Has been the Placement Officer for the college since inception."
            },
            "civil": {
                "name": "Dr. Marthi Kameswara Rao",
                "image": "<img src='https://mvsrec.edu.in/images/all_img/civil_mkameswararao.jpg'>",
                "description": ", the Head of the Civil Engineering Department at MVSR Engineering College, joined the institution in 2017. With 30 years of teaching experience, he has served in various roles including lecturer, assistant professor, professor, and principal. He graduated in Civil Engineering in 1989, earned a PG degree in Structural Engineering in 1994, and obtained his Ph.D. from IIT Bombay in 2004. His expertise lies in Structural Design, Finite Element Methods, Composite Structures, and High-Performance Concrete. Dr. Rao has guided 14 M.Tech theses and one Ph.D. scholar, and he has published 50 papers in reputed journals. He is a recognized research supervisor at JNTU Hyderabad and K L University Vijayawada. Dr. Rao is a Fellow of the Institution of Engineers and the Indian Association of Structural Engineers, and he is the central coordinator for NAAC at MVSR Engineering College."

            },
            "automobile":
                {
                    "name": " Dr. Gangaraju Srinivasa Sarma",
                    "image": "<img src='https://mvsrec.edu.in/images/AE/hod-ae--2021.jpeg'>",
                    "description": ", the Head of the Department of Automotive Engineering and Design at MVSREC, brings a wealth of experience to his role. Graduating in Mechanical Engineering from Bapatla Engineering College in 1993, he obtained his M.Tech from College of Engineering, Anantapur. With a Ph.D. from Osmania University in Biomass Gasification, his expertise spans Combustion, Heat Transfer, Gasification, and Artificial Intelligence. He began his career at MVSREC in 1994 after a stint at Voltas as a Graduate Engineer Trainee. Dr. Sarma has authored numerous technical papers and received several awards, including the Best Teacher Award thrice at MVSREC and the Lifetime Best Teacher Award from Matrusri Education Society. An active member of SAE and the Indian Combustion Society, he was also honored with the Best Teacher Award by COGNIZANT TECHNOLOGY SOLUTIONS."
                },
            "ECE":
                {
                    "name": "  Dr. S. Suryanarayana",
                    "image": "<img src='data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAJQBDgMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAFAgMEBgcBAAj/xAA8EAABAwIEAwUFBgUFAQEAAAABAAIDBBEFEiExBkFREyIyYXEUM0KBkQcjNENSsRVicqHBJCU10eGCFv/EABkBAAMBAQEAAAAAAAAAAAAAAAECAwQABf/EACURAAICAQQCAgIDAAAAAAAAAAABAhEDEiExMkFRBEITMyIjYv/aAAwDAQACEQMRAD8Ay1oXQvBdXns2CgF1cC6AgMKCUEkJSRgOW7wVt4NOWoVU5hWzg5l6i/mihMnBqOEzE2up1ZmAGuqiYRGGWvqpVfJoNEkl/WYvIQpbmlGa2yrVay9c+3VWaj/CC/RV2qbescR1Wz6IK5ETts35KZhA1Uecd35KXg4udEqCF2eEJqsP3R9FIa3u6DZR67SI+idgRj32gm8w/qVMiCufH3enGUE2PJU2JZZ8mvHwInCZaTyT86ZauiFjjZZW7EBPx1dQNA9MBORjVMBoIRVVVbxqS2oqj+YVHgtYKdGBpouFOxPqnG/aFSmNqiB3ynKNgLhcBFoom2GiKTFtAbJVfrK6G1H6ijvYNPILwp2/pC5xZ1oCiOcbuKK4O5zmkONyE9LAOz2GyYwkWlcPNFRBqCdW0iB3osl4lJ/ib8pstdq/w7vRZFxL/wAm9OuTgXnfzcVy7/1FdAuVIbSucL2ThFpQKYklazcpIqWdVLSy1pEoJYUYThLbM0lK4sKkPhKTQlaU4HA80jQ1o7zCuvA7QXk+apXMK98BMLiT5pbonPg0nDmkJytGYgDql0LcrbpVSAXCx5oroZGtwhTjLSN9FXZvxT/VWRtm0jfRVuUj2l1+q1vqgLk5P4FJw2eKmidLPI2ONg1c42CgYjUx0tO+aY9xo2G58gqvVOnxBwFXcRNN2w3sB69SpSlpVlsWJ5JUg9i3HTWv7HB4s5G87x3fkFWqvFa6tkPtVRPIN7ZrD6KbFSMA0aB6BOGmZbYfRRlOUj08fx4wWxXKi4v3Dfz1QSpy58skPzsrtNCA3QIdVU8bxq3VJdDvHZR6uAuB7F1yPhO6GmQxuyv0cORVuq6Joc6wt6IBX0mcnqOdlaEl5M2TFRDbUXUqnfmcELaMriDuEQpPEE0lRBBqAbKfDaygwnRSmO0UrOcUEad7WuGql/xBkbw0nfZCojd4UaQh1YwHrt1TwduhJRpFwgkbK0EHdPXau4ZSh0DDaykzUwjbe11p0GexiQAxb8lDw1oEzvVRKrEWRSOjJ19VKwZ4kdmHNBoNhSs/Du9FkHEv/KPWw1otA70WP8Sf8pIlQ6BcZs4X2RmGSPswgxaeSWJHgbp0zmiDWOOe10zBd7wE5WH7xcovfhUXUL7BaGjJYNUmalc3YorA0ZQPJIqmgXss+orQBmL4xupWHyOf4uqjYgLEhPYYnkk4WKuwU+IK3cI4i2jdleDY9FUR4grlwlRNnjc862NlkUdWxTJwXalx1p0aCnv4w0uAN73UGOgjY4CwU9mGseQLLv8AJldBduLNNMNDayBvrmOmJ2ueasVPg7RANOSqvEFD7IJZGEgMBctTToVJNkeSpbXYnI9zr01HZjW8nS2uT8gQktj7WQutzUDDWuZSRMcTmIzP/qOpRenGgUMk72R6nx4KCsU2DKFxzRspJaS3RMlhCSi9sjyw3ZdCqqMjvIzJ4DdCKwkNLQNErQ1gWpFySglW0Eu0R6rachI0sg1QNSUETkVOqGWrbfQONij9Hgspsc48rILi8fiI5KxYPizPYoMwcXBgBPmtT3gmefPaQRhweX9YUkYRKPjC9Fi7D8LlJbi0Z3Dvop0hbY3FhcjTfOLhRJ8HnNSJGvGiLR4lGdg76JwVcZ3a76IpI62S6CaeCANe4XHRLq6uZ0RAPJQ/aY+hSu2jItYqmoWip1dDXz1rng90lW3hqlkhiAkOqTmj6IrhpaW2C5SFaJFcLwO9FkWPwOkxWTKter/cO9FkuOVLY8VluUQoGeyS9AueyS9ApRxCLqk/xCLqiEr9Z7xeo/fBerPGu0QvMFb6HPsHW1JaLLhnMmiWKfM1p8lwwZNVndUVQLxHVOYXsmsROtk/hW4Ty/WBdgmPEFovADM1ORbd6ztviC0jgHu0ZP8AOs+PkObgvLcPY7UqXHTCNoKgDEhG4NKIMnEjQoY1LXuZLC9L7oKpcZttSVGm7bK3Ufugqrxk0upZwBc5V6MuoYcopkMgjbmeQGjUknYJwY9hsEeaSdobycTuh9XGJiGZDKG7gHQev91CkGGPikc6lpLtBJMut/SwWWMbe56jlS2LXSY/h1U0CGpjcTyDlKdUxFhdposqY2AVXa08TGAWIfEdPorlDW0rcLD31tO3NoCZRa/RFqmGL9kvFcbpKKB0spOUG2gVVm40pZJiyOnleBzt+6gzsGKVOSWoc0G5Gl2gdU5JNFgmHsc6Z7O11aWxAtfbex3KdQTFlNipeIIpxZzHNvztom3SMlZnjKG1dbqQ4Nva5dkymx6hcp6uKNhc1r5OuSNxCnLG/COU/ZExMauJS8F/D2/S4hQK6uExJDHNA5FSMMm7Jhb1N1TQ9FGebWrYssAGlwiVPTOeLtbcIRRS9q9rVeMNpB2A9E2LFqM+SdAWMBjhmFkQjZG4DUKPjEQhuRuhMWIOjeAbrp41EEZakWZsDXbWTjaQeSiYbVdtlRmMDok02HVRGFILbBTqSERt2SmjUaKQ1tmplAVz3I1f+HcsY4jt/F5lsuIfhnLFOI5f94mCZIdEOw6LoA6JsSXSw5NQSDWe8SsP/EBJrPeJeHNvPZU+hz7FjZJlFkiR+YKQyG4+SRJDYbLKXRX8Q1cVJwrdN4jEcydw1tgqS/WIuwTb4gtK4Cbeg/8ApZq3xBaXwJph2m+ZRw8nZ+Cx1Mf3oRKkP3cagTBxmFgidLH92wcwuh2dmRlgofchVLjhwFLIxzXObIchP6QVbaIWhCq/Foa6KUOFxZacnQfF3Vmd0WHOpopYu3ldmkJIc8kZXNABHzDlEqcLz0DqCWASxdp2uYEhwda2/oj9HGJSyY2LwLEHYj/Gv+U57PnBDmuGY6gFZVJ8nq6U0VWmp5GGQ9hFkghs0AbW80Zw6gjlwETV1HE2d0ZAaWg5ByAU2akaGCCOIsjLgXE7lFJY2iglBbs0BoGy5tsaMaM2wd0zJZQIonAkxgbkAdR8lPqRU1cYjqJRJGx2ZrZWg5T81wulp8VcImhrHkB2ml7/ALo8aWV+romAdbXTan4F0bblQmw97qh0sveJFifmES9phgpnQjZuinVVPWNzANaWnW1rAH+5/uq/V0j2Nc59w71SSYdCQDxGCOXQbZt0llNHDGGgd/cFcq3ljbg6N3SjmkdnDTbIAqwukiE6phfh9pdVsaeoWp0rGsphfoskwmWWGpYSx2h6LRaTES6mtY7c1uxJKJ5WW9QL4hqA1xDVW4AZpbXG6IY9I+aSzAbnoFzBMNnDg98enmpZ4+imL0F8Mg7ENKORSqHHBIAPu0+2GVuuXZQVxKuFkqGZrpLBEgbsCAUZf7QA4I8PdhVW8SElUiHiOlM9YZxGf96nW5Yn+FesK4hN8Zn9UIclkRmJ3mmozZOBFodMi1fvE9hZtUBNVY+8SqBwbMCU30A+5boj3UmV2XdRoapmXdNVNW13NZaZa0QsRmbchdw911Cq3GRxIUzDmkAXVJ9BV2CLfGFovA0xFGGgfEs6b4wtL4CiElGzTclQx7Wzs/BawC85gLlT2slZyIRHC8Oj7RrnDwoxUU7JGEFo01XYYSncjNQMpXP7HnsqrxO99n+YV6jjDYwLBU/ihoyu05LVkX8Do9kVOgcA0W6Ke6pbE24tfmgkUhjcQdNUP4ixb2OlzA76E9FkSvZHrKSoPSVcgglqwGOc0dxrzYfVVyXjOZlDKKhkLpAT7knL/dVapx2prKUtcX5ejf2SsNw11RC6aSaOMAE5SLkqqx1yI8kn1Qil4grKp8kWWPv3sMpzA+t1f8HxF0lJEKi3aZe96rMpaeWCpLo5GgA7joksxqop6jMyS7WbgHdGWPU9hY5XDsahWVFw61lWcSlDg7MbkKeyd09LHK64zsDghFWLtdc7qNFJSALtXXtcXVlweOBtK0uLcziSbqtnug9VNpXOcxpudeh0TXRnycFshjgzA935IpDJG1tgQVT4g7TvH6ojTscSO8fqnjlaM7gWBrInSatbZEad0EY5BAYIXaWeVJFO7fMUXlbF0IOCeHqF01MVjqED9nf+orhgcBcuK78jDQUZLG2QnREWStewWVZERds5GsOYWsAJuipvgVw8kiri7VhaqZXcIU1RUvlewXKudZL2MRd0VKrOLYoah8ZOrTZMFDDuDKfk2yadwbDfVqfHGEJ5ro4shPxLgmd1NOHOuEy2nLTcIiW3XMiVZHVFnBXZEa1+1yliNztypIaEtrQlcw6RuOnB3UqJgZsFxoS1OUmxlEU094LVPs3ANLHf9SypviC1T7Nx/po/6v8AKOPySzcGtUwaG3ATskjcp6lRoL5F14s66tCVKkRoe/LVL4o1BCuv5fyVL4m3KfJ1FXJScRYIpQ8HSQXHrzQLG6CLEaQxyOc1wdcFqt9XRtrKUx7P3a7zVVme+OZ0U4LXsPeaeSzcG7HNNUyPheAUNNTtDo+0duXO5ojJWYbSxiKWga+x0ys38jolU0wLm7W/ZS5WUpbd9s3VG2Wi0iu1jo6wnsqcRtHINshzMHpp5CHwi3PkjlTURs0aBYnkg89eIwbkb6Lk2CbT5C1TLEyNjItGtGUDyQPEJg1pbfUps13aOJzaIdVTGR977oJCN2cDTM5sbR3nIfh9WaPEDHI8mMus7p6oj2opqCWrdoXAsi8zzKrbjrc7rRjhadmfLLc0GA6DW45eaMUUTnWNlTuF672iRtHM6z2juH9XktLwmFroRsfMJFialRNzGYbt30snzKA267XwGNwsobwXwFU/C6JyyJOj38RZ2mS4BXayptCXDTRAjGRVhxvvZFK2O9K70KMcXs5yO4bWiUm5281Z6FwLBZZfQ1cjK0s212Wk4MS6mYT0U3CmV8WPYt+Ff6LGMUN8RnP8y2bFz/pX+ixbE3f7hP8A1lcBDQSrBMiQDdd7REYkry8vLOXOpQSV1ccLCWE2EsFKxhTfEFqv2a/ho/6v8rKAe8Fqv2bODaWMlw8X+U0PJDNwa3T+BckHesk08zMniTc1SwP3RjJEb2JX5apfE51Ktb6n7rQa2VJ4mqmsLnSvDW9XaALRPeOwq5IEewTmKcOQ41h5dGRFWxsPZy9fJ3kqbi3HmH0LezommrmGlxowfNVPEeLMaxaBzaqudHTu0bT05yN+ZGrvmbJY4m+R9VMJCsnp3lkjbljiCQb6hIqMYu4EEj1RDDuHpf8A8Xh+LMu7OXiRo1ytzHKfS1ghM9Oz4xb5JXCnRpU7WxHnxIm4zDyQ2Rznm+pU2RtNGbnW3QKO+TMT2MZt1KOx24w5xDbDdSsNoH1Z7R/cgB7z+voiGE8Pz1bmyTMdkO2m6tOIYVDhmDVFVN4ImaM2BOwATRhYkp1sjMsfrW1VV2UAywQdxjRz6lD2s+I2PqpEoJkc4jVxufmuBt+R+S0JUiHI03NG8PjOVwNwWnYq24Dx1V4eWx10IqIhu5ps/wD9VZewNZexv5ps8wNlwKs16HirBcZY1tNVBkxHu5u4flfdSIWjI4HSyxci+4H0RjCeJMSwoCNk3bQX9zLrp5HcJ1JVROeO3aLxVgCXTrdEpbPpweRCq9Jj9FicgBd2Ep+CQ/sdkeElqdrOm6k5qLKKDaKw5mTEybaX0WkYE4GkZ6KiTUxfUOfbmrRhFe2GBrCdQoymmy+lqIYxk/6R/osWxEZ6+a2+crUcaxZgpH6g6LLJHOfVveB4nXugnbE3Qqnw+aY2aFLGDzD4SrFw9FG6MGS10bdDB5KyhsI5szpeXF5YjWdSgkJQXHCglJCUEB0Kb4gtG4CDxC0i9rlZw3xBabwCQKAEkABxuSmgrZDNwaDBNKGaFdqKunoozUYhUxwxN3ke6wWYY99p/s1XJS4LTxTtZdrqiVxDb/ygb/MrOcYxrEcZqDNidZLO7kHHujyDRoF2L40ruRnNd4o+1/D6WN1Pw9Tmsm27eXuxj05u/ZZJjfEOKY5O6XE6x8xvowd1jfINGiG2uumNbkkkckKhYCMxTznF1geSYjuxuU9Ut5Ja7KO9rb1THH0R9nlK2XgPCY3tDmvpRdpGhuqvxRweaZ8ktM0upybi27P/ABScD41hocNocLwmhfVR0sbIppyNGm3Ic/7I9FjlTXyGOVkOV3d7IwnNa2u7tQu/C8i2CsyxvczHDuGKjEq9tPBFr+Y43ysHUq64fwNh9C5r5AZ5R8TxoD6J538QoJHugrezgHeLYIo2tNuWU+V1IpuL2urRR1FJ21/zYDrf06ed0I/GcFb3DL5Gt0iXDhjI7WZ9As7+1jEj29Ng0DgBEO2qLdT4R+5+i1KTGMNZRz1XbjLAwvew91wA12K+eMWrZsVxWqrqk3lqJDI4D4b7D5Cw9AjQoMczvb2XQ27wAdk8ddTyTF5JLiP7scyRqVwT1SWgAZje4TVjzTvY5Wgne67bvHyXHDWVcsnQy4XC3VccNWHREsPxyupCGtl7WEfly6/Q7hQS1JykoNJ8nJ0XfDsbo64Bt+ym5xu5+h5ojew0I16LOAxzdQbEI3hWMOiYIKyS4Hgk5+h/7WbJhreJeGTww5iryIjqbKpOqWtlNwEfxF7nwZmuDmkXBHNVGckSm/VLgVvcbJVbB2lxo04s1TBxGSNSfqqw1w5pYIOy0GegjddXl5ZDUeSlxeSnCwury8uGQqPxKw1lZPR8Dv8AZ5CwzzCF7hvlO9lxeVcPYjl4KTBpCbLo5ei8vLYZxQXTqF1eXBOfEf6glb2HVx/wuLy4Bsf2T00QwusdluXza38gFbqumijr3yMbZwiB005n/pcXlbD2J5OpUOJMRnbSytZkaO8bAdAV77O4mVNTiFZK0GZpaxp5AHfRcXlXKTwjv2uv9m4bp2Qta3t6gNe62tgL2v6rHzplPVeXlmNBwAE2OwTWcskNra73Xl5cE84knVcPhXV5A47bULhGq6vLjjjgvDcLy8uOGnnUpl5IGi4vIM4J4RUSGCanJvGBmAPJDKj3h9V5eUY92V+o2Eq5Xl5UER//2Q=='>",
                    "description": "Professor & HOD Qualification(s) : Ph.D ,Email : suryanarayana_ece@mvsrec.edu.in"

                },
            "EEE":
                {
                    "name": " Dr. C. V. GOPALA KRISHNA RAO",
                    "image": "<img src='https://mvsrec.edu.in/images/all_img/cvgkrao.jpg'>",
                    "description": "As an Associate Professor and Head of the Electrical and Electronics Engineering Department at MVSREC, Dr.C. V. GOPALA KRISHNA RAO  holds a Ph.D. with a specialization in Power Systems. With a keen interest in Power Systems, he imparts knowledge in subjects such as Network Analysis, Power Systems, and Power Electronics at the undergraduate level, and High Voltage Engineering at the postgraduate level. With a substantial publication record, including 8 international papers and 2 national papers, and participation in 2 international conferences, he contributes significantly to academia. Dr. [Name] has conducted 4 workshops and attended 15, showcasing his commitment to continuous learning and knowledge dissemination. Recognized for his excellence in teaching, he has been honored with the Best Teacher Award thrice at MVSREC."
                },
            "mechanical":
                {
                    "name": "Dr. M.Madhavi",
                    "image": "<img src='https://mvsrec.edu.in/images/Mechanical/Faculty/DrMadhavi.jpg'>",
                    "description": "As the Head of the Mechanical Engineering Department, Dr. M.Madhavi leads with a distinguished academic background. Holding a Ph.D. in Mechanical Engineering, specializing in the experimental evaluation of composite pressure vessels, awarded in October 2010, she brings profound expertise to her role. With an M.Tech in Mechanical Engineering from Sri Venkateswara University, Tirupati, and a B.Tech from V.R. Siddhartha Engineering College, Vijayawada, her academic journey underscores a dedication to excellence. Her leadership ensures the department's continued advancement and innovation in Mechanical Engineering education and research."
                },
            "mba":
                {
                    "name": " Dr.N.Sravanthi",
                    "image": "<img src='https://mvsrec.edu.in/images/MBA/Staff/sravanthi.jpg'>",
                    "description": "is an esteemed academician with a wealth of qualifications including a Ph.D., MBA, M.Com, and UGC-NET, serves as the Professor and Head of the department. With over 31 years of teaching experience, she has imparted knowledge across a broad spectrum of subjects ranging from Statistics for Management to Business Law. Despite her extensive teaching commitments, Dr. Sravanthi has made significant contributions to academia through 10 published papers and active participation in seminars and conferences, having presented in 3 and attended 18. Her dedication to continuous learning is evident from her participation in 2 refresher courses and FDPs. As the Head, she steers the department towards academic excellence and innovation."
                },
            "applied science":
                {
                    "name": " Dr. A.R.Subrahmanyam,",
                    "image": "<img src='https://mvsrec.edu.in/images/arsubramanyam-hod.jpg'>",
                    "description": " with a Ph.D. in Physics from OU, leads the Department of Science and Humanities with 22 years of teaching experience. Specializing in solid-state physics and material science, his research focuses on conducting polymers. He boasts 18 publications in national and international journals and has presented his work at prestigious conferences. Recognized as an outstanding teacher, he established physics laboratories and organized extracurricular events. Since joining in December 2000, his contributions have greatly enriched the college community."

                }
            # Add other departments as needed
        }

        if department in hod_details:
            hod = hod_details[department]
            message = f"{hod['name']} is the {hod['description']}.  {hod['image']}"
        else:
            message = "Sorry, I don't have details for that department."

        dispatcher.utter_message(text=message)

        return []